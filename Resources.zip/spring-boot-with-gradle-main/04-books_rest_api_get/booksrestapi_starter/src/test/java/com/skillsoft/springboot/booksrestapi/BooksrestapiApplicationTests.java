package com.skillsoft.springboot.booksrestapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BooksrestapiApplicationTests {

	@Test
	void contextLoads() {
	}

}

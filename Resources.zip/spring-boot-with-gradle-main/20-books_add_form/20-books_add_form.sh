######################################## 
demo-19-BooksUIAddForm 
########################################


########################################
### Add book form and delete book

# Load booksui_starter

# Show the following files

BookController.java
add-book.html
book-details.html








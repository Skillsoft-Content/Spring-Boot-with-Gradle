package com.skillsoft.springboot;

public class CarConfig {

    public Engine engine() {
        return new Engine("V8 Engine");
    }
}

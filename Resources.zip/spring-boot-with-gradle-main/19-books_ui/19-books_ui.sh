######################################## 
demo-19-BooksUI
########################################

# Start with the booksui_starter

# Show the files

build.gradle
application.properties
Book.java
BookRepository.java
BookController.java
BookApplication.java

styles.css
book-list.html
book-details.html

# Fill in all the details in the following files to display
book-list.html
book-details.html


























